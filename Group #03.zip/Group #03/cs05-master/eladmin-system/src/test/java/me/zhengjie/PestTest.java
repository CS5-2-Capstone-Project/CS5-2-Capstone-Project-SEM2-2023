package me.zhengjie;

import me.zhengjie.modules.pms.pest.domain.Pesttb;
import me.zhengjie.modules.pms.pest.service.dto.PestDto;
import me.zhengjie.modules.pms.pest.service.impl.PestServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.bind.annotation.PathVariable;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class PestTest {

    @Resource(name = "pestServiceImpl")
    private PestServiceImpl pestService;


    @Test
    public void queryById() {
        PestDto cn = pestService.queryById("1", "EN");
        System.out.println(cn);
    }


    @Test
    public void createApp() {
        Pesttb resource = new Pesttb();
        resource.setLanguages("EN");
        resource.setPestDescCb("fdfdfd");
        resource.setPestDescEn("test");
        resource.setPestIntroEn("dsfsdf");
        resource.setPestIntroCb("sadsa");
        resource.setPestAudioCb("dsadsa");
        resource.setPestAudioEn("fdgfd");
        resource.setPesticideNm("teste");
        resource.setEnabled(1);
        pestService.create(resource);
    }

    @Test
    public void updateApp() {
        Pesttb pest = new Pesttb();
        pest.setId("1");
        pest.setPestDescEn("abcdefg");
        pest.setEnabled(2);
        pestService.update(pest);
    }


    @Test
    public void pestAssoc() {
        Pesttb resources = new Pesttb();
        resources.setId("1");
        List<String> pesticideIds = new ArrayList<>();
        pesticideIds.add("10");
        pesticideIds.add("12");
        pesticideIds.add("13");
        resources.setPesticideIds(pesticideIds);
        pestService.pestAssoc(resources);
    }


}
