package me.zhengjie;


import me.zhengjie.modules.pms.pesticide.domain.Pesticidetb;
import me.zhengjie.modules.pms.pesticide.service.dto.PesticideDto;
import me.zhengjie.modules.pms.pesticide.service.impl.PesticideServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class PesticideTest {


    @Resource(name = "pesticideServiceImpl")
    private PesticideServiceImpl pesticideService;


    @Test
    public void queryApp() {
        pesticideService.queryAll(null, null);
    }

    @Test
    public void queryById() {
        PesticideDto pesticideDto = pesticideService.queryById("1", "EN");
        System.out.println(pesticideDto);
    }

    @Test
    public void createApp() {
        Pesticidetb pesticidetb = new Pesticidetb();
        pesticidetb.setPesticideCbNm("abc");
        pesticidetb.setPesticideEnNm("def");
        pesticidetb.setEnabled(1);
        pesticidetb.setPesticideAudEn("123");
        pesticidetb.setPesticideAudCb("456");
        pesticidetb.setPesticideDescEn("qwer");
        pesticidetb.setPesticideDescCb("asdf");
        pesticidetb.setPesticideIntroEn("0987");
        pesticidetb.setPesticideIntroCb("fdsfds");
        pesticideService.create(pesticidetb);
    }

    @Test
    public void updateApp() {
        Pesticidetb pesticidetb = new Pesticidetb();
        pesticidetb.setId(1L);
        pesticidetb.setPesticideEnNm("test");
        pesticideService.update(pesticidetb);
    }

}
