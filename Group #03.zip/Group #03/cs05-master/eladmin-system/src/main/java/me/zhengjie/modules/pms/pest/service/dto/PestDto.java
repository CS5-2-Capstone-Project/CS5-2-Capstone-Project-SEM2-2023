package me.zhengjie.modules.pms.pest.service.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import me.zhengjie.base.BaseDTO;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Getter
@Setter
public class PestDto extends BaseDTO implements Serializable {

    private String id;

    private String pestNameEn;

    private String pestNameCb;

    private String cookingPic;


    private String pestIntroEn;
    private String pestIntroCb;
    private String pestDescEn;
    private String pestDescCb;
    private String pestAudioEn;
    private String pestAudioCb;


    private String pestName;
    private String pestIntro;
    private String pestDesc;
    private String pestAudio;


    private int enabled;
    private int type;

    private String createBy;

    private String updateBy;

    private Timestamp createTime;

    private Timestamp updateTime;

    private List<Object> pesticideIds;
}
