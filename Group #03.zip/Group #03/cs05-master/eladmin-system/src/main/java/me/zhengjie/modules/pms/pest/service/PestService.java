package me.zhengjie.modules.pms.pest.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.extension.service.IService;
import me.zhengjie.modules.pms.pest.service.dto.PestDto;
import me.zhengjie.modules.pms.pesticide.domain.Pesticidetb;
import me.zhengjie.modules.pms.pesticide.service.dto.PesticideDto;
import org.springframework.data.domain.Pageable;

import me.zhengjie.modules.pms.pest.domain.Pesttb;
import me.zhengjie.modules.pms.pest.service.dto.PestQueryCriteria;


public interface PestService extends IService<Pesttb> {

    /**
     * Paging query
     *
     * @param criteria
     * @param pageable
     * @return /
     */
    Object queryAll(PestQueryCriteria criteria, Pageable pageable);

    /**
     * Query all data
     *
     * @param criteria
     * @return /
     */
    List<Pesttb> queryAll(PestQueryCriteria criteria);

    /**
     * Query by ID
     *
     * @param id /
     * @return /
     */
    Pesttb findById(String id);

    /**
     * create
     *
     * @param resources /
     */
    void create(Pesttb resources);

    /**
     * edit
     *
     * @param resources /
     */
    void update(Pesttb resources);

    /**
     * delete
     *
     * @param ids /
     */
    void delete(Set<String> ids);

    /**
     * Derived data
     *
     * @param queryAll /
     * @param response /
     * @throws IOException /
     */
    void download(List<Pesttb> queryAll, HttpServletResponse response) throws IOException;

    void pestAssoc(Pesttb resources);

    List<PesticideDto> getByPestId(Pesttb resources);

    PestDto queryById(String id,String languages);

    List<PesticideDto> getByPestId1(Pesttb resources);
    List<PesticideDto> getByPestId2(Pesttb resources);

    Object findPestAndPesticide(PestQueryCriteria criteria);
}
