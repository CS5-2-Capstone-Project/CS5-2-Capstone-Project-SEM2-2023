package me.zhengjie.modules.pms.pesticide.rest;

import java.io.IOException;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import me.zhengjie.modules.pms.pesticide.domain.Pesticidetb;
import me.zhengjie.modules.pms.pesticide.service.dto.PesticideQueryCriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import me.zhengjie.annotation.Log;
import me.zhengjie.modules.pms.pesticide.service.PesticideService;

@RestController
@RequiredArgsConstructor
@Api(tags = "Pesticide：Pesticide management")
@RequestMapping("/api/pesticide")
public class PesticideController {

    @Autowired
    private PesticideService pesticideService;

    @ApiOperation("Derived pesticide data")
    @GetMapping(value = "/download")
    public void exportApp(HttpServletResponse response, PesticideQueryCriteria criteria) throws IOException {
        pesticideService.download(pesticideService.queryAll(criteria), response);
    }

    @ApiOperation(value = "Query pesticide")
    @GetMapping
    public ResponseEntity<Object> queryApp(PesticideQueryCriteria criteria, Pageable pageable) {
        return new ResponseEntity<>(pesticideService.queryAll(criteria, pageable), HttpStatus.OK);
    }

    @ApiOperation(value = "Query pesticide")
    @GetMapping("/{id}")
    public ResponseEntity<Object> queryById(@PathVariable("id") String id, String languages) {
        return new ResponseEntity<>(pesticideService.queryById(id, languages), HttpStatus.OK);
    }

    @Log("Newly added pesticide")
    @ApiOperation(value = "Newly added pesticide")
    @PostMapping
    public ResponseEntity<Object> createApp(@Validated @RequestBody Pesticidetb resources) {
        pesticideService.create(resources);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @Log("Modified pesticide")
    @ApiOperation(value = "Modified pesticide")
    @PutMapping
    @PreAuthorize("@el.check('pesticide:edit')")
    public ResponseEntity<Object> updateApp(@Validated @RequestBody Pesticidetb resources) {
        pesticideService.update(resources);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @Log("Pesticide deletion")
    @ApiOperation(value = "Pesticide deletion")
    @DeleteMapping
    public ResponseEntity<Object> deleteApp(@RequestBody Set<Long> ids) {
        pesticideService.delete(ids);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
