package me.zhengjie.modules.pms.pest.rest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import me.zhengjie.annotation.Log;
import me.zhengjie.modules.pms.pest.domain.Pesttb;
import me.zhengjie.modules.pms.pest.service.PestService;
import me.zhengjie.modules.pms.pest.service.dto.PestQueryCriteria;
import me.zhengjie.modules.pms.pesticide.domain.Pesticidetb;
import me.zhengjie.modules.pms.pesticide.service.dto.PesticideDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequiredArgsConstructor
@Api(tags = "Pest：Pest management")
@RequestMapping("/api/pest")
public class PestController {

    @Autowired
    private PestService pestService;

    @ApiOperation("Derived Pest data")
    @GetMapping(value = "/download")
    public void exportApp(HttpServletResponse response, PestQueryCriteria criteria) throws IOException {
        pestService.download(pestService.queryAll(criteria), response);
    }

    @ApiOperation(value = "Query Pest")
    @GetMapping
    public ResponseEntity<Object> queryApp(PestQueryCriteria criteria, Pageable pageable) {
        return new ResponseEntity<>(pestService.queryAll(criteria, pageable), HttpStatus.OK);
    }

    @ApiOperation(value = "Query Pest")
    @GetMapping("/findPestAndPesticide")
    public ResponseEntity<Object> findPestAndPesticide(PestQueryCriteria criteria) {
        return new ResponseEntity<>(pestService.findPestAndPesticide(criteria), HttpStatus.OK);
    }


    @ApiOperation(value = "Query Pest")
    @GetMapping("/{id}")
    public ResponseEntity<Object> queryById(@PathVariable("id") String id, String languages) {
        return new ResponseEntity<>(pestService.queryById(id, languages), HttpStatus.OK);
    }


    @Log("Newly added Pest")
    @ApiOperation(value = "Newly added Pest")
    @PostMapping
    public ResponseEntity<Object> createApp(@Validated @RequestBody Pesttb resources) {
        pestService.create(resources);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @Log("Modified Pest")
    @ApiOperation(value = "Modified Pest")
    @PutMapping
    public ResponseEntity<Object> updateApp(@Validated @RequestBody Pesttb resources) {
        pestService.update(resources);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @Log("Pest deletion")
    @ApiOperation(value = "Pest deletion")
    @DeleteMapping
    public ResponseEntity<Object> deleteApp(@RequestBody Set<String> ids) {
        pestService.delete(ids);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/pestAssoc")
    public ResponseEntity<Object> pestAssoc(@Validated @RequestBody Pesttb resources) {
        pestService.pestAssoc(resources);
        return new ResponseEntity<>(HttpStatus.OK);
    }


    @GetMapping("/getByPestId")
    public ResponseEntity<Object> getByPestId(Pesttb resources) {
        List<PesticideDto> list = pestService.getByPestId(resources);
        Map<String, Object> result = new HashMap<>();
        result.put("content", list);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }



    @GetMapping("/getAllByPestId")
    public ResponseEntity<Object> getAllByPestId(Pesttb resources) {
        List<PesticideDto> list = pestService.getByPestId1(resources);
        Map<String, Object> result = new HashMap<>();
        result.put("content", list);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }



    @GetMapping("/findByPestId")
    public ResponseEntity<Object> findByPestId(Pesttb resources) {
        List<PesticideDto> list = pestService.getByPestId2(resources);
        Map<String, Object> result = new HashMap<>();
        result.put("content", list);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

}
