package me.zhengjie.modules.pms.pest.service.dto;

import java.sql.Timestamp;
import java.util.List;

import lombok.Data;
import me.zhengjie.annotation.Query;

@Data
public class PestQueryCriteria {

    private String pestNameEn;


    private String languages;

    private String pestName;

    private String pestDesc;

}
