package me.zhengjie.modules.pms.pesticide.service.dto;

import lombok.Data;
import me.zhengjie.base.BaseDTO;
import me.zhengjie.modules.pms.pest.service.dto.PestDto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

@Data
public class PesticideDto extends BaseDTO implements Serializable {

    private Long id;

    private String pesticideEnNm;
    private String pesticideCbNm;

    private String pesticidePic;
    private String pesticideIntroEn;
    private String pesticideIntroCb;

    private String pesticideDescEn;
    private String pesticideDescCb;

    private String pesticideAudEn;
    private String pesticideAudCb;


    private String pesticideNm;
    private String pesticideIntro;
    private String pesticideDesc;
    private String pesticideAud;


    private int enabled;
    private int type;

    private String createBy;

    private String updateBy;

    private String pesticideClsnm;

    private Timestamp createTime;

    private Timestamp updateTime;


    private List<PestDto> pestDtoList;

}
