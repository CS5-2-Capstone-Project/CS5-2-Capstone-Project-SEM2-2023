package me.zhengjie.modules.pms.pest.service.mapstruct;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import me.zhengjie.modules.pms.pest.domain.Pesticidepesttb;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author wenbin
 * @email *****@mail.com
 * @date 2023-04-18 17:11:38
 */
@Mapper
public interface PesticidepesttbMapper extends BaseMapper<Pesticidepesttb> {

}
