package me.zhengjie.modules.pms.pest.domain;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import me.zhengjie.base.BaseEntity;

import javax.persistence.Table;
import javax.persistence.Transient;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

@Data
@Table(name = "pesttb")
public class Pesttb extends BaseEntity implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    private String id;

    private String pestNameEn;

    private String pestNameCb;

    private String cookingPic;


    private String pestIntroEn;
    private String pestIntroCb;
    private String pestDescEn;
    private String pestDescCb;
    private String pestAudioEn;
    private String pestAudioCb;


    private int enabled;

    private String createBy;

    private String updateBy;

    private Timestamp createTime;

    private Timestamp updateTime;

    @TableField(exist = false)
    private List<String> pesticideIds;


    @TableField(exist = false)
    private String languages;

    @TableField(exist = false)
    private String pesticideNm;

    public void copy(Pesttb source) {
        BeanUtil.copyProperties(source, this, CopyOptions.create().setIgnoreNullValue(true));
    }
}
