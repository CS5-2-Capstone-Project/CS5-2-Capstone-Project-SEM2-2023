package me.zhengjie.modules.pms.pest.service.mapstruct;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import me.zhengjie.modules.pms.pest.domain.Pesttb;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PestMapper extends BaseMapper<Pesttb> {

}
