package me.zhengjie.modules.pms.pest.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import me.zhengjie.base.BaseEntity;

import java.io.Serializable;

/**
 * 
 *
 * @author wenbin
 * @email *****@mail.com
 * @date 2023-04-18 17:11:38
 */
@Data
@TableName("pesticidepesttb")
public class Pesticidepesttb extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private Long id;

	/**
	 * 
	 */
	@TableField("pest_id")
	private String pestId;

	/**
	 * 
	 */
	@TableField("pesticide_id")
	private String pesticideId;


}
