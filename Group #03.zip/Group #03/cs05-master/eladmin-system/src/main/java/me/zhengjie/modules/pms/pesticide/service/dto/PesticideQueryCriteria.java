package me.zhengjie.modules.pms.pesticide.service.dto;

import java.sql.Timestamp;
import java.util.List;

import lombok.Data;
import me.zhengjie.annotation.Query;

@Data
public class PesticideQueryCriteria {

    private String pesticideNm;

    private String languages;

}
