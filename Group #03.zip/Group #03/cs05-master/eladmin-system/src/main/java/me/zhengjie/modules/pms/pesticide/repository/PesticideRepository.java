package me.zhengjie.modules.pms.pesticide.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import me.zhengjie.modules.pms.pesticide.domain.Pesticide;

public interface PesticideRepository extends JpaRepository<Pesticide, Long>, JpaSpecificationExecutor<Pesticide> {
}
