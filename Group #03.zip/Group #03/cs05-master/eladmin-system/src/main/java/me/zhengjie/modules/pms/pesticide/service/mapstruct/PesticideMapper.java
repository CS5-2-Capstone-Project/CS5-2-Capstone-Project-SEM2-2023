package me.zhengjie.modules.pms.pesticide.service.mapstruct;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import me.zhengjie.modules.pms.pesticide.domain.Pesticidetb;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PesticideMapper extends BaseMapper<Pesticidetb> {

}
