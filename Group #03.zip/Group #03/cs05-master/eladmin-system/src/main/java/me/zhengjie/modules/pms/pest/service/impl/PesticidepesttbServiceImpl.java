package me.zhengjie.modules.pms.pest.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import me.zhengjie.modules.pms.pest.domain.Pesticidepesttb;
import me.zhengjie.modules.pms.pest.service.PesticidepesttbService;
import me.zhengjie.modules.pms.pest.service.mapstruct.PesticidepesttbMapper;
import org.springframework.stereotype.Service;


@Service("pesticidepesttbService")
public class PesticidepesttbServiceImpl extends ServiceImpl<PesticidepesttbMapper, Pesticidepesttb> implements PesticidepesttbService {


}