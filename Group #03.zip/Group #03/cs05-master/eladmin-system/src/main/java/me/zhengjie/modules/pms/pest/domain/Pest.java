package me.zhengjie.modules.pms.pest.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.*;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import me.zhengjie.base.BaseEntity;

@Entity
@Getter
@Setter
@Table(name="pesttb")
public class Pest extends BaseEntity implements Serializable {

    @Id
	@Column(name = "ID")
	@ApiModelProperty(value = "ID", hidden = true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;

	@ApiModelProperty(value = "pestNameEn")
    private String pestNameEn;

	@ApiModelProperty(value = "pestNameCb")
	private String pestNameCb;

	@ApiModelProperty(value = "cookingPic")
	private String cookingPic;

	@ApiModelProperty(value = "descriptionEn")
	private String descriptionEn;

	@ApiModelProperty(value = "descriptionCb")
	private String descriptionCb;

	@ApiModelProperty(value = "enabled")
	private int enabled;

	@ApiModelProperty(value = "createBy")
	private String createBy;

	@ApiModelProperty(value = "updateBy")
	private String updateBy;

	@ApiModelProperty(value = "createTime")
	private Timestamp createTime;

	@ApiModelProperty(value = "updateTime")
	private Timestamp updateTime;

    public void copy(Pest source){
        BeanUtil.copyProperties(source,this, CopyOptions.create().setIgnoreNullValue(true));
    }
}
