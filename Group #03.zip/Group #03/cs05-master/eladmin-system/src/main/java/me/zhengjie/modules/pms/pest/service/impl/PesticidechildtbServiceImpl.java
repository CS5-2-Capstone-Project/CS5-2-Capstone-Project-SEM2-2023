package me.zhengjie.modules.pms.pest.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import me.zhengjie.modules.pms.pest.domain.Pesticidechildtb;
import me.zhengjie.modules.pms.pest.service.PesticidechildtbService;
import me.zhengjie.modules.pms.pest.service.mapstruct.PesticidechildtbMapper;
import org.springframework.stereotype.Service;


@Service("pesticidechildtbService")
public class PesticidechildtbServiceImpl extends ServiceImpl<PesticidechildtbMapper, Pesticidechildtb> implements PesticidechildtbService {


}