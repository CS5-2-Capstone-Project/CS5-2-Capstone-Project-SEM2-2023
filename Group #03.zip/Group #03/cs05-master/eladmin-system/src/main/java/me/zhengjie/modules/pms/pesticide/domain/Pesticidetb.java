package me.zhengjie.modules.pms.pesticide.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.*;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import me.zhengjie.base.BaseEntity;

@Data
@Table(name = "pesticidetb")
public class Pesticidetb extends BaseEntity implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    private String pesticideEnNm;
    private String pesticideCbNm;

    private String pesticidePic;
    private String pesticideIntroEn;
    private String pesticideIntroCb;

    private String pesticideDescEn;
    private String pesticideDescCb;

    private String pesticideAudEn;
    private String pesticideAudCb;

    private int enabled;

    private String createBy;

    private String updateBy;

    private Timestamp createTime;

    private Timestamp updateTime;

    public void copy(Pesticidetb source) {
        BeanUtil.copyProperties(source, this, CopyOptions.create().setIgnoreNullValue(true));
    }

}
