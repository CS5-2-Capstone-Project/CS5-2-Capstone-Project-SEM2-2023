package me.zhengjie.modules.pms.pesticide.service;

import com.baomidou.mybatisplus.extension.service.IService;
import me.zhengjie.modules.pms.pesticide.domain.Pesticidetb;
import me.zhengjie.modules.pms.pesticide.service.dto.PesticideDto;
import me.zhengjie.modules.pms.pesticide.service.dto.PesticideQueryCriteria;
import org.springframework.data.domain.Pageable;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Set;


public interface PesticideService extends IService<Pesticidetb> {

    /**
     * Paging query
     *
     * @param criteria
     * @param pageable
     * @return /
     */
    Object queryAll(PesticideQueryCriteria criteria, Pageable pageable);

    /**
     * Query all data
     *
     * @param criteria
     * @return /
     */
    List<Pesticidetb> queryAll(PesticideQueryCriteria criteria);

    /**
     * Query by ID
     *
     * @param id /
     * @return /
     */
    Pesticidetb findById(Long id);

    /**
     * create
     *
     * @param resources /
     */
    void create(Pesticidetb resources);

    /**
     * edit
     *
     * @param resources /
     */
    void update(Pesticidetb resources);

    /**
     * delete
     *
     * @param ids /
     */
    void delete(Set<Long> ids);

    /**
     * Derived data
     *
     * @param queryAll /
     * @param response /
     * @throws IOException /
     */
    void download(List<Pesticidetb> queryAll, HttpServletResponse response) throws IOException;

    PesticideDto queryById(String id, String languages);
}
