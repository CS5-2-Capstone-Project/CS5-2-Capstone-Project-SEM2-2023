package me.zhengjie.modules.pms.pest.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import me.zhengjie.base.BaseEntity;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 
 *
 * @author wenbin
 * @email *****@mail.com
 * @date 2023-04-18 17:11:38
 */
@Data
@TableName("pesticidechildtb")
public class Pesticidechildtb extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private Long id;

	/**
	 * 
	 */
	@TableField("language_id")
	private Integer languageId;

	/**
	 * 
	 */
	@TableField("pesticide_id")
	private String pesticideId;

	/**
	 * 
	 */
	@TableField("pesticidecls_ord")
	private Integer pesticideclsOrd;

	/**
	 * 
	 */
	@TableField("description")
	private String description;

	/**
	 * 
	 */
	@TableField("audio")
	private String audio;

	/**
	 * 
	 */
	@TableField("create_by")
	private String createBy;

	/**
	 * 
	 */
	@TableField("update_by")
	private String updateBy;

	/**
	 * 
	 */
	@TableField("create_time")
	private Timestamp createTime;

	/**
	 * 
	 */
	@TableField("update_time")
	private Timestamp updateTime;


}
