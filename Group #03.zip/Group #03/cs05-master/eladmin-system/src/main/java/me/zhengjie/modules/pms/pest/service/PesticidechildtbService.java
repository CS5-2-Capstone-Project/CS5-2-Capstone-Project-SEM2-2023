package me.zhengjie.modules.pms.pest.service;

import com.baomidou.mybatisplus.extension.service.IService;
import me.zhengjie.modules.pms.pest.domain.Pesticidechildtb;

/**
 * 
 *
 * @author wenbin
 * @email *****@mail.com
 * @date 2023-04-18 17:11:38
 */
public interface PesticidechildtbService extends IService<Pesticidechildtb> {

}

