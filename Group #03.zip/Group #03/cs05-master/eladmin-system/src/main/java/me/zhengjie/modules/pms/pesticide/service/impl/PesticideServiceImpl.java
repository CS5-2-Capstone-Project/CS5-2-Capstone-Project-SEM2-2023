/*
 *  Copyright 2019-2020 Zheng Jie
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package me.zhengjie.modules.pms.pesticide.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import me.zhengjie.modules.pms.pest.domain.Pesticidepesttb;
import me.zhengjie.modules.pms.pest.service.PesticidepesttbService;
import me.zhengjie.modules.pms.pest.service.dto.PestDto;
import me.zhengjie.modules.pms.pest.service.dto.PestQueryCriteria;
import me.zhengjie.modules.pms.pesticide.domain.Pesticidetb;
import me.zhengjie.modules.pms.pesticide.service.PesticideService;
import me.zhengjie.modules.pms.pesticide.service.dto.PesticideDto;
import me.zhengjie.modules.pms.pesticide.service.dto.PesticideQueryCriteria;
import me.zhengjie.modules.pms.pesticide.service.mapstruct.PesticideMapper;
import me.zhengjie.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class PesticideServiceImpl extends ServiceImpl<PesticideMapper, Pesticidetb> implements PesticideService {


    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private PesticidepesttbService pesticidepesttbService;

    @Override
    public Object queryAll(PesticideQueryCriteria criteria, Pageable pageable) {
        Map<String, Object> result = new HashMap<>();
        if (criteria == null) {
            criteria = new PesticideQueryCriteria();
            criteria.setLanguages("en");
        } else {
            if (StringUtils.isBlank(criteria.getLanguages())) {
                criteria.setLanguages("en");
            }
        }
        String la = criteria.getLanguages();
        String wheresql = "";
        if (StringUtils.isNotBlank(criteria.getPesticideNm())) {
            wheresql += " and  pesticide_" + la + "_nm like '%" + criteria.getPesticideNm() + "%'";
        }

        String sql = " select *,(select pesticidenm from pesticideclasstb where id = t.pesticide_cls) pesticideClsnm," +
                " pesticide_" + la + "_nm  pesticideNm," +
                " pesticide_intro_" + la + " pesticideIntro," +
                " pesticide_desc_" + la + " pesticideDesc," +
                " pesticide_aud_" + la + " pesticideAud " +
                " from pesticidetb t where 1=1 ";

        String pagesql = "";
        if (pageable != null) {
            pagesql = " LIMIT " + (pageable.getPageNumber() * pageable.getPageSize()) + "," + pageable.getPageSize();
            Long aLong = jdbcTemplate.queryForObject("select count(1) from  pesticidetb where 1=1 " + wheresql, Long.class);
            result.put("totalElements", aLong);
        }

        RowMapper<PesticideDto> rm = BeanPropertyRowMapper.newInstance(PesticideDto.class);

        List<PesticideDto> query = jdbcTemplate.query(sql + wheresql + pagesql, rm);
        result.put("content", query);
        return result;
    }


    @Override
    public PesticideDto queryById(String id, String languages) {

        if (StringUtils.isBlank(languages)) {
            languages = "en";
        }
        String la = languages;
        String wheresql = " and  id =" + id;

        String sql = " select *,(select pesticidenm from pesticideclasstb where id = t.pesticide_cls) pesticideClsnm," +
                " pesticide_" + la + "_nm  pesticideNm," +
                " pesticide_intro_" + la + " pesticideIntro," +
                " pesticide_desc_" + la + " pesticideDesc," +
                " pesticide_aud_" + la + " pesticideAud " +
                " from pesticidetb t where 1=1 ";


        RowMapper<PesticideDto> rm = BeanPropertyRowMapper.newInstance(PesticideDto.class);

        List<PesticideDto> query = jdbcTemplate.query(sql + wheresql, rm);
        if (query != null && query.size() > 0) {
            String wheresql1 = "";
            List<Object> objects = pesticidepesttbService.listObjs(Wrappers.lambdaQuery(Pesticidepesttb.class)
                    .select(Pesticidepesttb::getPestId).eq(Pesticidepesttb::getPesticideId, id));
            if (objects != null && objects.size() > 0) {
                String str = "";
                for (Object object : objects) {
                    str += "," + object;
                }
                if (StringUtils.isNotBlank(str)) {
                    wheresql1 += " and  id in (" + str.substring(1) + ")";
                }
            }
            String sql1 = " select *," +
                    " pest_name_" + la + "  pestName," +
                    " pest_intro_" + la + " pestIntro," +
                    " pest_desc_" + la + " pestDesc," +
                    " pest_audio_" + la + " pestAudio " +
                    " from pesttb where 1=1 ";

            RowMapper<PestDto> rm1 = BeanPropertyRowMapper.newInstance(PestDto.class);
            List<PestDto> query1 = jdbcTemplate.query(sql1 + wheresql1, rm1);
            PesticideDto pesticideDto = query.get(0);
            pesticideDto.setPestDtoList(query1);



            return query.get(0);
        }
        return null;
    }

    @Override
    public List<Pesticidetb> queryAll(PesticideQueryCriteria criteria) {

        return this.list();
    }

    @Override
    public Pesticidetb findById(Long id) {
        return this.getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void create(Pesticidetb resources) {
        this.save(resources);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(Pesticidetb resources) {
        this.updateById(resources);
    }

    private void verification(Pesticidetb resources) {
        /*String opt = "/opt";
        String home = "/home";
        if (!(resources.getUploadPath().startsWith(opt) || resources.getUploadPath().startsWith(home))) {
            throw new BadRequestException("Files can only be uploaded to the opt directory or home directory ");
        }
        if (!(resources.getDeployPath().startsWith(opt) || resources.getDeployPath().startsWith(home))) {
            throw new BadRequestException("Files can only be deployed in the opt directory or the home directory ");
        }
        if (!(resources.getBackupPath().startsWith(opt) || resources.getBackupPath().startsWith(home))) {
            throw new BadRequestException("Files can only be backed up in the opt directory or the home directory ");
        }*/
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(Set<Long> ids) {
        for (Long id : ids) {
            this.removeById(id);
            pesticidepesttbService.remove(Wrappers.lambdaQuery(Pesticidepesttb.class)
                    .eq(Pesticidepesttb::getPesticideId, id));
        }
    }

    @Override
    public void download(List<Pesticidetb> queryAll, HttpServletResponse response) throws IOException {
        /*List<Map<String, Object>> list = new ArrayList<>();
        for (PesticideDto pesticideDto : queryAll) {
            Map<String,Object> map = new LinkedHashMap<>();
            map.put("Application name", pesticideDto.getName());
            map.put("port", pesticideDto.getPort());
            map.put("Upload directory", pesticideDto.getUploadPath());
            map.put("Deployment directory", pesticideDto.getDeployPath());
            map.put("Backup directory", pesticideDto.getBackupPath());
            map.put("Startup script", pesticideDto.getStartScript());
            map.put("Deployment script", pesticideDto.getDeployScript());
            map.put("Creation date", pesticideDto.getCreateTime());
            list.add(map);
        }
        FileUtil.downloadExcel(list, response);*/
    }


}
