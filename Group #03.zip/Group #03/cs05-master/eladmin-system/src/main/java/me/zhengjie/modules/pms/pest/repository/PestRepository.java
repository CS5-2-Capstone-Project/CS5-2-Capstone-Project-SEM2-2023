package me.zhengjie.modules.pms.pest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import me.zhengjie.modules.pms.pest.domain.Pest;

public interface PestRepository extends JpaRepository<Pest, String>, JpaSpecificationExecutor<Pest> {
}
