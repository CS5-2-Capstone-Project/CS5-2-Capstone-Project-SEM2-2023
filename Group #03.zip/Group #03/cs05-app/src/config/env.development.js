// 本地环境配置
module.exports = {
  title: 'vue-h5-template',
//   baseUrl: 'http://134.175.54.248:8001/', // 项目地址
  baseUrl: 'https://2016kt6872.oicp.vip/', // 项目地址
  baseApi: '/', // 本地api请求地址,注意：如果你使用了代理，请设置成'/'
  APPID: 'xxx',
  APPSECRET: 'xxx',
  $cdn: 'https://www.sunniejs.cn/static'
}
