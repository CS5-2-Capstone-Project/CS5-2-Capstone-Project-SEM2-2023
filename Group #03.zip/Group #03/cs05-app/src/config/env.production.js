// 正式
module.exports = {
    title: 'vue-h5-template',
    baseUrl: 'http://134.175.54.248:8002/', // 正式项目地址
    baseApi: 'http://134.175.54.248:8001/', // 正式api请求地址
    APPID: 'xxx',
    APPSECRET: 'xxx',
    $cdn: 'https://www.sunniejs.cn/static'
}