<template>
    <div class="app-container">
        <div class="layout-content">
            <keep-alive v-if="$route.meta.keepAlive">
                <router-view></router-view>
            </keep-alive>
            <router-view v-else></router-view>
        </div>
    </div>
</template>

<script>
    import TabBar from '@/components/TabBar'
    import { getToken } from '@/utils/auth'
    import { Notify } from 'vant';


    export default {
        name: 'AppLayout',
        data() {
            return {
                tabbars: [{
                        title: 'Shop',
                        to: {
                            name: 'home'
                        },
                        icon: 'shop-o'
                    }, {
                        title: 'Class',
                        to: {
                            name: 'class'
                        },
                        icon: 'apps-o'
                    }, {
                        title: 'Menu',
                        to: {
                            name: 'cooking'
                        },
                        icon: 'notes-o'
                    },
                    {
                        title: 'Mine',
                        to: {
                            name: 'about'
                        },
                        icon: 'user-o'
                    }
                ]
            }
        },
        components: {
            TabBar
        },
        mounted() {

        },
        methods: {
            handleChange(v) {
                console.log('tab value:', v)
            },
        }
    }
</script>