<template>

    <div class="body_css">

        <div class="home">
            <van-row>
                <van-col span="2" offset="1">
                    <van-icon name="wap-home-o" @click="toHome" class="add_icon" />
                </van-col>
                <van-col span="2" offset="7">
                    Detail
                </van-col>
            </van-row>
        </div>

        <div class="layout_css">

            <van-row>
                <van-col span="24">
                    <img :src="pestDetail.pesticidePic" class="bgc_img" alt="">
                </van-col>
            </van-row>

            <van-row class="content_css">
                <van-col :span="22">
                    <div class="body_right_header">{{ pestDetail.pesticideNm }}</div>
                </van-col>
                <van-col :span="2">
                    <van-icon size="30" @click="playAudio(pestDetail.pestAudio)" name="bullhorn-o" />
                </van-col>
            </van-row>
			<van-row class="content_css">
                <van-col :span="22">
                    <div class="body_right_header">{{ pestDetail.pesticideClsnm }}</div>
                </van-col>
            </van-row>
            <van-row class="content_css">
                <van-col :span="22">
                    <div class="body_right_header">{{ pestName }}</div>
                </van-col>
            </van-row>

            <van-row>
                <van-col span="24">
                    <div class="address_css">
                        <div class="content content-editor" v-html="pestDetail.pesticideIntro"></div>
                    </div>
                </van-col>
            </van-row>
        </div>
        <audio ref="audios" class="aud">
            <source :src="mp3" />
        </audio>
    </div>
</template>

<script>
    import { getPesticideDetail } from '@/api/home.js'


    export default {
        data() {
            return {
                title: '',
                query: {
                    id: null,
                    languages: null
                },
                pestDetail: [],
                mp3: '',
                pestName: []
            }
        },
        mounted() {
            var id = this.$route.query.id
            var languages = this.$route.query.languages
            this.query.id = id;
            this.query.languages = languages;
            this.getData()
        },
        methods: {
            getData() {
                getPesticideDetail(this.query).then(res => {
                    this.pestDetail = res;
                    this.pestName = res.pestDtoList[0]['pestName']
                })
            },
            playAudio(audio) {
                let music1 = new Audio();
                music1 = audio;
                this.$refs.audios.src = music1;
                this.$refs.audios.play()
            },
            change() {

            },
            toDetail() {
                this.$router.push('/detail');
            },
            toBooking() {
                this.$router.push('/booking');
            },
            toHome() {
                this.$router.go(-1)
            }
        }
    };
</script>

<style lang="scss" scoped>
    .user {
        &-poster {
            width: 100%;
            height: 53vw;
            display: block;
        }

        &-group {
            margin-bottom: 15px;
        }

        &-links {
            padding: 30px 0;
            font-size: 16px;
            text-align: center;
            background-color: #fff;

            .van-icon {
                display: block;
                font-size: 24px;
            }
        }
    }

    .layout_css {
        padding: 10px;
        background-color: #ebedf0;
        margin-bottom: 100px;
        margin-top: 10px;
    }

    .body_css {
        background-color: #ebedf0;
    }

    .van_row_css {
        font-size: 28px;
        margin-top: 10px;
        color: #FF6600;
    }

    .home {
        width: 100%;
        text-align: center;
        height: 100px;
        background-color: #fff;
        border-bottom: 1px #ebedf0 solid;
        font-size: 40px;
        line-height: 100px;
    }

    .img {
        height: 100px;
        width: 100px;
        margin-top: 40px;
    }

    .bgc {
        background-color: #fff;
        border-radius: 20px;
        margin-top: 10px;
    }

    .bodyImg {
        height: 200px;
        width: 200px;
        margin-top: 20px;
        margin-bottom: 10px;
    }

    .title {
        text-align: center;
        background-color: #ebedf0;
        border-top-left-radius: 30px;
        border-top-right-radius: 30px;
    }

    .img_name {
        font-size: 16px;
        height: 30px;
        line-height: 30px;
    }

    .body_right {
        // width: 67%;
        height: 200px;
        display: flex;
        flex-direction: column;
        margin-top: 20px;

    }

    .body_right_header {
        // width: 100%;
        // background-color: green;
        height: 0.8rem;
        font-size: 0.5rem;
        font-weight: 700;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .body_right_body {
        // width: 100%;

        display: flex;
        flex-direction: row;
        height: 80px;
        color: #AAAAAA;
        font-size: 16px;
    }

    .address_css {
        // word-wrap: break-word;
        // word-break: normal;
        font-size: 28px;
        // display: -webkit-box;
        // -webkit-box-orient: vertical;
        // -webkit-line-clamp: 3; //行数
        // overflow: hidden;
        // color: #AAAAAA;
    }

    .body_right_body_color {
        color: #AAAAAA;
    }

    .body_right_footer {
        // width: 100%;
        // background-color: yellow;
        // height: 0.8rem;
        display: flex;
        font-size: 0.32rem;
        // flex-direction: row;
        justify-content: space-between;
        align-items: center;
        margin-top: 10px;

    }

    .body_right_footer_score {
        // align-self: flex-end;
        color: #FF7744;
        font-size: 28px;

    }

    .btn {
        font-size: 8px;
        width: 160px;
        height: 50px;
    }

    .location {
        display: inline-block;
    }

    .bgc_img {
        width: 100%;
        height: 300px;
    }

    .btn_css {
        display: flex;
        justify-content: space-between;

        // justify-self: ;
    }

    .content_css {
        display: flex;
        justify-content: start;
    }
</style>