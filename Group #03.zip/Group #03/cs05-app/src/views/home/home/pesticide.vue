<template>
    <div>
        <div class="home">
            <van-row>
                <div v-if="query.pesticideNm == '' || query.pesticideNm == null">

                    <van-col span="2" offset="1">
                        <van-icon name="wap-home-o" @click="toHome" class="add_icon" />
                    </van-col>
                    <van-col span="15" offset="2">
                        Active ingredient
                    </van-col>



                </div>
                <div v-else>
                    <van-col span="2" offset="1">
                        <van-icon name="wap-home-o" @click="toHome" class="add_icon" />
                    </van-col>
                    <van-col span="2">
                        <van-icon name="replay" @click="refresh" class="add_icon" />
                    </van-col>
                    <van-col span="15">
                        Active ingredient
                    </van-col>
                </div>

            </van-row>
        </div>

        <audio ref="audios" class="aud">
            <source :src="mp3" />
        </audio>

        <van-row>
            <van-col span="22" :offset="1">
                <van-search v-model="query.pesticideNm" @search="onSearch" placeholder="active ingredient" />
            </van-col>
        </van-row>

        <div class="layout_css">
            <van-row class="bgc" v-for="(item, index) in dataList" :key="index">
                <van-swipe-cell>
                    <van-col span="22" offset="1">
                        <div class="body_right">
                            <div class="body_right_header" @click="toDetail(item.id)">{{item.pesticideNm}}</div>
                        </div>
                    </van-col>
                </van-swipe-cell>
            </van-row>
        </div>
    </div>
</template>

<script>
    import { getPesticideList } from '@/api/home.js'
    import urlData from '@/utils/url'
    import { Toast, Notify } from 'vant'


    export default {
        data() {
            return {
                dataList: [],
                url: urlData.url,
                showPopover: false,
                actions: [{ text: 'Add Shop' }, { text: 'Message' }],
                read: 0,
                mp3: '',
                query: {
                    languages: 'en',
                    pesticideNm: ''
                },
                title: 'EN'
            }
        },
        mounted() {
            var id = this.$route.query.id
            this.query.id = id;
            this.getData()
        },
        beforeDestroy() {
            clearInterval(this.timer)
            this.timer = null;
        },
        methods: {
            getData() {
                getPesticideList(this.query).then(res => {
                    this.dataList = res.content;
                })
            },
            onSearch() {
                this.getData();
            },
            toHome() {
                this.$router.go(-1)
            },
            toDetail(id) {
                this.$router.push({ name: 'pesticideDetail', query: { id: id, languages: this.query.languages } });
            },
            playAudio(audio) {
                let music1 = new Audio();
                music1 = audio;
                this.$refs.audios.src = music1;
                this.$refs.audios.play()
            },
            change() {
                if (this.query.languages == 'en') {
                    this.query.languages = 'cb'
                    this.title = 'CB'
                } else {
                    this.query.languages = 'en'
                    this.title = 'EN'
                }

                this.getData();
            },
            refresh() {
                this.query.pesticideNm = ''
                this.getData()
            }
        }
    };
</script>

<style lang="scss" scoped>
    .add_icon {
        font-size: 50px;
        // position: fixed;
        // right:30px;
        top: 5px;
        background-color: #fff;
        // color: #1989fa;
    }

    .delete_button {
        height: 240px;
        border-radius: 10px;
    }

    .user {
        &-poster {
            width: 100%;
            height: 53vw;
            display: block;
        }

        &-group {
            margin-bottom: 15px;
        }

        &-links {
            padding: 30px 0;
            font-size: 16px;
            text-align: center;
            background-color: #fff;

            .van-icon {
                display: block;
                font-size: 24px;
            }
        }
    }

    .layout_css {
        padding: 10px;
        background-color: #ebedf0;
        margin-bottom: 100px;
    }

    .home {
        width: 100%;
        text-align: center;
        height: 100px;
        background-color: #fff;
        // border-bottom: 1px #D9D9D9 solid;
        border-bottom-left-radius: 5%;
        border-bottom-right-radius: 5%;
        font-size: 40px;
        line-height: 100px;
    }

    .img {
        height: 100px;
        width: 100px;
        margin-top: 40px;
    }

    .bgc {
        background-color: #fff;
        border-radius: 20px;
        margin-top: 10px;
    }

    .bodyImg {
        height: 200px;
        width: 200px;
        margin-top: 20px;
        margin-bottom: 10px;
    }

    .title {
        text-align: center;
        background-color: #ebedf0;
        border-top-left-radius: 30px;
        border-top-right-radius: 30px;
    }

    .img_name {
        font-size: 16px;
        height: 30px;
        line-height: 30px;
    }

    .body_right {
        // width: 67%;
        height: 200px;
        display: flex;
        flex-direction: column;
        margin-top: 20px;

    }

    .body_right_header {
        // width: 100%;
        height: 200px;
		line-height: 200px;
        font-size: 0.5rem;
        font-weight: 700;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1; //行数
        overflow: hidden;
		text-align: center;
    }

    .body_right_body {
        // width: 100%;
        display: flex;
        flex-direction: row;
        height: 78px;
        color: #AAAAAA;
        font-size: 16px;
        margin-top: 10px;
    }

    .address_css {
        word-wrap: break-word;
        word-break: normal;

        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 3; //行数
        overflow: hidden;
        color: #AAAAAA;
    }

    .body_right_body_color {
        color: #AAAAAA;
    }

    .body_right_footer {
        // width: 100%;
        // background-color: yellow;
        // height: 0.8rem;
        display: flex;
        font-size: 0.32rem;
        flex-direction: column;
        justify-content: end;
        align-items: center;
        margin-top: 10px;
        text-align: center;

    }

    .body_right_footer_score {
        // align-self: flex-end;
        color: #FF7744;
    }

    .btn {
        font-size: 8px;
        width: 160px;
        height: 50px;
    }

    .location {
        display: inline-block;
    }

    .icon {
        font-size: 40px;
        margin-bottom: 5px;
    }
</style>

<style type="css/text">
    .van-popover--dark {
		margin-left: 25px !important;
		margin-top: -10px !important;
	}
</style>