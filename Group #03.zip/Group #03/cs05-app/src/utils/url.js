const urlData = {
    // url: 'http://localhost:5000', 
    url: 'https://2016kt6872.oicp.vip',
    // url: 'http://182.92.192.47:35001',
}

export default urlData