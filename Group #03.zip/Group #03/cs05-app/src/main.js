// 兼容 IE
// https://github.com/zloirock/core-js/blob/master/docs/2019-03-19-core-js-3-babel-and-a-look-into-the-future.md#babelpolyfill
import 'core-js/stable'
import 'regenerator-runtime/runtime'

import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import 'element-ui/lib/theme-chalk/index.css';

import Chat from 'vue-beautiful-chat'

// 设置 js中可以访问 $cdn
import { $cdn } from '@/config'
Vue.prototype.$cdn = $cdn

// 全局引入按需引入UI库 vant
import '@/plugins/vant'
// 引入全局样式
// import '@/assets/css/index.scss'
// 移动端适配
import 'amfe-flexible'

// filters
import './filters'
Vue.config.productionTip = false

import {
    DatetimePicker,
    Button,
    Popup,
    ActionSheet,
    RadioGroup,
    Radio,
    Field,
    Col,
    Row,
    Icon,
    CellGroup,
    Cell,
    Search,
    DropdownMenu,
    DropdownItem,
    Form,
    Picker,
    Uploader,
    SwipeCell,
    Checkbox,
    CheckboxGroup,
    Toast,
    Popover,
	Dialog,
} from 'vant';

new Vue({
    el: '#app',
    router,
    store,
    render: h => h(App)
})


Vue.use(DatetimePicker).use(Button).use(Popup).use(ActionSheet).use(RadioGroup).use(Radio).use(Field).use(Col).use(Row).use(Icon).use(CellGroup)
    .use(Cell).use(Search).use(DropdownMenu).use(DropdownItem).use(Form).use(Picker).use(Uploader).use(SwipeCell).use(Checkbox).use(CheckboxGroup)
    .use(Toast).use(Popover).use(Dialog).use(Chat);