/**
 * 基础路由
 * @type { *[] }
 */
export const constantRouterMap = [{
    path: '/',
    component: () => import('@/views/layouts/index'),
    redirect: '/home',
    meta: {
        title: '首页',
        keepAlive: false
    },
    children: [{
        path: '/home',
        name: 'home',
        component: () => import('@/views/home/home/index'),
        meta: { title: 'home', keepAlive: false }
    }, {
        path: '/pesticide',
        name: 'pesticide',
        component: () => import('@/views/home/home/pesticide'),
        meta: { title: 'home', keepAlive: false }
    }, {
        path: '/pestDetail',
        name: 'pestDetail',
        component: () => import('@/views/home/home/pestDetail'),
        meta: { title: 'home', keepAlive: false }
    }, {
        path: '/pesticideDetail',
        name: 'pesticideDetail',
        component: () => import('@/views/home/home/pesticideDetail'),
        meta: { title: 'home', keepAlive: false }
    }]
}]