import request from '@/utils/request'

export function getPestList(params) {
    return request({
        url: 'api/pest',
        method: 'get',
        params
    })
}

export function getPesticideList(params) {
    return request({
        url: 'api/pest/findByPestId',
        method: 'get',
        params
    })
}

export function getPestDetail(params) {
    return request({
        url: 'api/pest/' + params.id,
        method: 'get',
        params
    })
}

export function getPesticideDetail(params) {
    return request({
        url: 'api/pesticide/' + params.id,
        method: 'get',
        params
    })
}

export function getSearchList(params) {
    return request({
        url: '/api/pest/findPestAndPesticide',
        method: 'get',
        params
    })
}